# وضعیت آزمون سورس Android

## انجام‌شده در محیط فعلی

- بررسی وجود و ساختار فایل‌های Kotlin، XML، Gradle و Workflow.
- بررسی نحوی مقدماتی با Kotlin compiler؛ بررسی بدون diagnostic نحوی مانند `expecting` انجام شد، اما compilation کامل به‌دلیل نبود Android/AndroidX dependencyها انجام نشد.
- موجودبودن آزمون واحد تقویم شمسی و تست‌های `testDebugUnitTest` در workflow.
- بررسی قرارداد API Sync با نسخهٔ Windows 0.4.5.
- بررسی ZIP و محتوای بستهٔ تحویلی پس از بسته‌بندی.

## انجام‌نشده / نیازمند اجرا در CI

- compilation کامل Gradle و اجرای آزمون‌های Android روی runner دارای SDK.
- آزمون روی گوشی فیزیکی و اتصال به سرور Windows در یک LAN واقعی.
- آزمون انواع OEM/Android و بازیابی از قطع برق/اتصال حین دانلود.
- آزمون امنیت شبکهٔ واقعی؛ نسخهٔ Windows فعلی در LAN از HTTP استفاده می‌کند.

بنابراین سورس و workflow آماده‌اند، اما تا اجرای موفق GitHub Actions نباید APK را buildشده یا روی دستگاه تأییدشده تلقی کرد.

# انتشار پروژه در GitHub

این بسته برای قرارگرفتن در مخزن `MrUtility01/NetAdministrator` آماده شده است. از آن‌جا که دسترسی نوشتن احراز هویت‌شده به GitHub در محیط ساخت در دسترس نبود، این پروژه هنوز push نشده است.

## روش پیشنهادی با Git

1. ZIP را در یک پوشه استخراج کن.
2. در GitHub مخزن مقصد را باز کن و اگر محتوای مهمی ندارد آن را clone کن؛ بهتر است پیش از جایگزینی، محتویات موجود را بررسی کنی.
3. فایل‌ها و پوشه‌های پروژهٔ اندروید را در ریشهٔ مخزن کپی کن.
4. از PowerShell در ریشه اجرا کن:

```powershell
git status
git add README_FA.md .gitignore app build.gradle.kts settings.gradle.kts gradle.properties .github docs
git commit -m "Add offline-first Android learning client"
git push origin main
```

اگر شاخهٔ اصلی `master` است، به‌جای `main` از نام شاخهٔ واقعی استفاده کن.

## دریافت APK

پس از push، تب **Actions** را باز کن. Workflow با نام Android CI اجرا می‌شود و APK را به‌صورت Artifact پیوست می‌کند. برای انتشار Release، یک tag مثل `v1.0.0` بساز و push کن:

```powershell
git tag v1.0.0
git push origin v1.0.0
```

Workflow انتشار APK آزمایشی امضاشده با کلید debug را به GitHub Release پیوست می‌کند. این APK برای تست است؛ انتشار عمومی نهایی به کلید release اختصاصی و مدیریت امن آن در GitHub Secrets نیاز دارد.

> فایل‌های `local.properties`، keystore، رمزها و پایگاه دادهٔ شخصی نباید commit شوند.

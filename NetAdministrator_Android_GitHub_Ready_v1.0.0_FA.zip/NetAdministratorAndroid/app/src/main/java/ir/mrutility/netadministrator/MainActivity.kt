package ir.mrutility.netadministrator

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Bookmarks
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudDownload
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.MoreTime
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Style
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material3.*
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.window.Dialog
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.room.withTransaction
import com.google.gson.Gson
import ir.mrutility.netadministrator.data.*
import ir.mrutility.netadministrator.ui.NetAdminTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.BufferedInputStream
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NetAdministratorApp() }
    }
}

private val quotes = listOf(
    "هر شبکهٔ پایدار، نتیجهٔ فهم دقیق جزئیات است.",
    "امروز یک مفهوم را عمیق یاد بگیر؛ فردا چند مسئله را سریع‌تر حل می‌کنی.",
    "عیب‌یابی خوب از مشاهدهٔ دقیق شروع می‌شود، نه از حدس.",
    "دانش وقتی ماندگار می‌شود که آن را بازیابی، تمرین و به کار ببری.",
    "هر آزمایش کنترل‌شده، یک فرضیهٔ اشتباه را از بین می‌برد.",
    "پیشرفت حرفه‌ای یعنی بتوانی هم راه‌حل را توضیح بدهی و هم محدودیتش را.",
    "یک یادداشت دقیق امروز، ساعت‌ها عیب‌یابی فردا را کوتاه می‌کند.",
    "اول وضعیت را ثبت کن؛ بعد تغییر بده؛ در پایان نتیجه را ثابت کن."
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NetAdministratorApp() {
    val context = LocalContext.current
    val db = remember { AppDatabase.get(context) }
    val dao = db.learningDao()
    val sync = remember { SyncRepository(context, db) }
    val preferences = remember { context.getSharedPreferences("visual_preferences", Context.MODE_PRIVATE) }
    var themeMode by remember { mutableStateOf(preferences.getString("theme", "system") ?: "system") }
    var route by remember { mutableStateOf("home") }
    var selectedChapterId by remember { mutableStateOf<String?>(null) }
    var selectedItem by remember { mutableStateOf<ContentEntity?>(null) }
    var message by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }
    var syncBusy by remember { mutableStateOf(false) }
    var syncProgress by remember { mutableStateOf("") }
    var serverUrl by remember { mutableStateOf(sync.savedBaseUrl()) }
    var password by remember { mutableStateOf("") }
    var searchGlobal by remember { mutableStateOf("") }
    var studyStartAt by remember { mutableLongStateOf(0L) }
    val scope = rememberCoroutineScope()

    val chapters by dao.observeChapters().collectAsState(initial = emptyList())
    val allCards by dao.observeContentKind("flashcard").collectAsState(initial = emptyList())
    val tasks by dao.observeTasks().collectAsState(initial = emptyList())
    val reviews by dao.observeReviewStates().collectAsState(initial = emptyList())
    val studySessions by dao.observeStudySessions().collectAsState(initial = emptyList())
    val chapterItems by dao.observeChapterContent(selectedChapterId ?: "__none__").collectAsState(initial = emptyList())
    val chapterCount by dao.observeChapterCount().collectAsState(initial = 0)
    val contentCount by dao.observeContentCount().collectAsState(initial = 0)
    val openTaskCount by dao.observeOpenTaskCount().collectAsState(initial = 0)

    LaunchedEffect(Unit) {
        if (serverUrl.isNotBlank()) syncProgress = "آدرس همگام‌سازی ذخیره شده است."
    }

    val backupExport = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri: Uri? ->
        if (uri != null) scope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val output = context.contentResolver.openOutputStream(uri) ?: error("فایل پشتیبان باز نشد")
                    output.use { writeBackupArchive(context, db, it) }
                }
                message = "پشتیبان ZIP ذخیره شد؛ بانک، کارها، سابقه، تنظیمات و رسانه‌های دانلودشده در آن قرار دارند. رمز/نشست سرور صادر نشده است."
            } catch (e: Exception) { errorMessage = "ساخت پشتیبان ناموفق بود: ${e.message}" }
        }
    }
    val backupRestore = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) scope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val input = context.contentResolver.openInputStream(uri) ?: error("فایل خوانده نشد")
                    input.use { restoreBackupArchive(context, db, it) }
                }
                message = "بازیابی پشتیبان کامل شد."
            } catch (e: Exception) { errorMessage = "بازیابی انجام نشد: ${e.message}" }
        }
    }

    NetAdminTheme(themeMode) {
        CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
            val fullScreen = route == "reader" || route == "quiz"
            Scaffold(
                topBar = {
                    CenterAlignedTopAppBar(
                        title = { Text(when (route) {
                            "home" -> "دانشنامه جامع شبکه"
                            "chapters" -> "فهرست فصل‌ها"
                            "chapter" -> chapters.firstOrNull { it.id == selectedChapterId }?.title ?: "محتوای فصل"
                            "reader" -> selectedItem?.title ?: "مطالعهٔ درس"
                            "quiz" -> "آزمون آفلاین"
                            "review" -> "فلش‌کارت و مرور"
                            "tasks" -> "کارها و برنامه‌ریزی"
                            "settings" -> "اتصال و تنظیمات"
                            "search" -> "جست‌وجوی سراسری"
                            "reports" -> "گزارش پیشرفت"
                            else -> "دانشنامه جامع شبکه"
                        }, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                        navigationIcon = {
                            if (fullScreen || route == "chapter") IconButton(onClick = {
                                route = if (fullScreen && selectedChapterId != null) "chapter" else "chapters"
                                selectedItem = null
                            }) { Icon(Icons.Default.ArrowBack, "بازگشت") }
                        },
                        actions = {
                            IconButton(onClick = { route = "search" }) { Icon(Icons.Default.Search, "جست‌وجو") }
                            if (route != "settings") IconButton(onClick = { route = "settings" }) { Icon(Icons.Default.Settings, "تنظیمات") }
                        }
                    )
                },
                bottomBar = {
                    if (!fullScreen) NavigationBar {
                        val tabs = listOf(
                            Triple("home", "خانه", Icons.Default.Dashboard),
                            Triple("chapters", "فصل‌ها", Icons.Default.MenuBook),
                            Triple("review", "مرور", Icons.Default.Style),
                            Triple("tasks", "کارها", Icons.Default.TaskAlt),
                            Triple("settings", "همگام‌سازی", Icons.Default.Sync)
                        )
                        tabs.forEach { (key, label, icon) ->
                            NavigationBarItem(selected = route == key || (key == "chapters" && route == "chapter"), onClick = { route = key }, icon = { Icon(icon, null) }, label = { Text(label, fontSize = 11.sp) })
                        }
                    }
                },
                snackbarHost = { SnackbarHost(remember { SnackbarHostState() }) }
            ) { padding ->
                Column(Modifier.fillMaxSize().padding(padding)) {
                    if (message.isNotBlank()) InlineNotice(message, false) { message = "" }
                    if (errorMessage.isNotBlank()) InlineNotice(errorMessage, true) { errorMessage = "" }
                    when (route) {
                        "home" -> DashboardScreen(
                            chapterCount, contentCount, openTaskCount, allCards.size, tasks,
                            onChapters = { route = "chapters" }, onReview = { route = "review" }, onTasks = { route = "tasks" }, onSync = { route = "settings" }, onReports = { route = "reports" },
                            studyStartAt = studyStartAt, onToggleStudy = {
                                if (studyStartAt == 0L) { studyStartAt = System.currentTimeMillis(); message = "زمان مطالعه ثبت شد؛ بعد از پایان روی توقف بزن." }
                                else { val end = System.currentTimeMillis(); scope.launch(Dispatchers.IO) { dao.addStudySession(StudySessionEntity(startedAt = studyStartAt, durationSeconds = ((end - studyStartAt) / 1000).coerceAtLeast(0), chapterId = selectedChapterId, activity = "مطالعهٔ آزاد")) }; studyStartAt = 0L; message = "زمان مطالعه در گزارش محلی ثبت شد." }
                            }
                        )
                        "chapters" -> ChaptersScreen(chapters, searchGlobal, { searchGlobal = it }, { ch -> selectedChapterId = ch.id; route = "chapter" })
                        "chapter" -> ChapterScreen(
                            chapter = chapters.firstOrNull { it.id == selectedChapterId }, items = chapterItems,
                            onOpen = { item -> selectedItem = item; route = "reader" },
                            onQuiz = { route = "quiz" }
                        )
                        "reader" -> selectedItem?.let { ReaderScreen(it, chapters.firstOrNull { ch -> ch.id == it.chapterId }?.title ?: "") } ?: EmptyState("محتوایی انتخاب نشده است.")
                        "quiz" -> QuizScreen(chapterItems.filter { it.kind == "question" }, { route = "chapter" })
                        "review" -> ReviewScreen(allCards, reviews, chapters, onRate = { card, rating ->
                            scope.launch(Dispatchers.IO) {
                                val old = dao.reviewState(card.uid) ?: ReviewStateEntity(card.uid)
                                dao.upsertReview(nextReviewState(old, rating))
                            }
                        }, onOpen = { selectedItem = it; route = "reader" })
                        "tasks" -> TasksScreen(tasks, onAdd = { title, desc, due, priority -> scope.launch { dao.upsertTask(TaskEntity(title = title, description = desc, dueAt = due, priority = priority)); message = "کار ذخیره شد." } }, onToggle = { task, done -> scope.launch { dao.setTaskDone(task.id, done) } }, onDelete = { task -> scope.launch { dao.deleteTask(task.id) } })
                        "settings" -> SyncSettingsScreen(
                            serverUrl = serverUrl, onServerUrl = { serverUrl = it }, password = password, onPassword = { password = it },
                            progress = syncProgress, busy = syncBusy, themeMode = themeMode, onTheme = { themeMode = it; preferences.edit().putString("theme", it).apply() },
                            onConnectSync = {
                                scope.launch {
                                    syncBusy = true; errorMessage = ""; message = ""
                                    try {
                                        if (password.isNotEmpty()) { syncProgress = "ورود به سرور…"; sync.connectAndLogin(serverUrl, password); password = "" }
                                        val summary = sync.syncAll { text -> android.os.Handler(android.os.Looper.getMainLooper()).post { syncProgress = text } }
                                        syncProgress = "همگام‌سازی کامل شد: ${summary.updatedChapters} فصل تازه/تغییریافته، ${summary.unchangedChapters} فصل بدون تغییر و ${summary.downloadedItems} رکورد دریافت شد."
                                        message = if (summary.errors.isEmpty()) "همگام‌سازی موفق بود." else "همگام‌سازی با ${summary.errors.size} خطای فرعی پایان یافت."
                                        if (summary.errors.isNotEmpty()) errorMessage = summary.errors.take(3).joinToString(" | ")
                                    } catch (e: Exception) { errorMessage = e.message ?: "همگام‌سازی ناموفق بود." }
                                    finally { syncBusy = false }
                                }
                            },
                            onDisconnect = { scope.launch { sync.disconnect(); syncProgress = "اتصال ذخیره‌شده پاک شد."; message = "نشست محلی سرور پاک شد؛ فصل‌های دانلودشده حذف نشدند." } },
                            onBackup = { backupExport.launch("netadministrator-android-backup-${PersianCalendar.now().replace('/', '-')}.zip") },
                            onRestore = { backupRestore.launch(arrayOf("application/zip", "application/json", "text/json", "*/*")) }
                        )
                        "search" -> SearchScreen(searchGlobal, { searchGlobal = it }, chapters, dao, onOpen = { item -> selectedItem = item; selectedChapterId = item.chapterId; route = "reader" })
                        "reports" -> ReportsScreen(tasks, reviews, studySessions, chapters)
                        else -> EmptyState("صفحه پیدا نشد.")
                    }
                }
            }
        }
    }
}

@Composable
private fun InlineNotice(text: String, error: Boolean, onDismiss: () -> Unit) {
    Surface(color = if (error) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.secondaryContainer, modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(text, Modifier.weight(1f), color = if (error) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSecondaryContainer, fontSize = 12.sp)
            TextButton(onClick = onDismiss) { Text("بستن") }
        }
    }
}

@Composable
private fun DashboardScreen(chapterCount: Int, contentCount: Int, taskCount: Int, cardCount: Int, tasks: List<TaskEntity>, onChapters: () -> Unit, onReview: () -> Unit, onTasks: () -> Unit, onSync: () -> Unit, onReports: () -> Unit, studyStartAt: Long, onToggleStudy: () -> Unit) {
    val quote = remember { quotes[(LocalDate.now().dayOfYear % quotes.size)] }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Surface(shape = RoundedCornerShape(24.dp), color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("مسیر یادگیری تو ادامه دارد", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text("«$quote»", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text("تاریخ شمسی: ${PersianCalendar.now()}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("فصل‌های محلی", chapterCount.toString(), Icons.Default.MenuBook, Modifier.weight(1f))
                StatCard("محتوا", contentCount.toString(), Icons.Default.Bookmarks, Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatCard("کارت‌ها", cardCount.toString(), Icons.Default.Style, Modifier.weight(1f))
                StatCard("کار باز", taskCount.toString(), Icons.Default.TaskAlt, Modifier.weight(1f))
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("شروع سریع", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Button(onClick = onChapters, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.MenuBook, null); Spacer(Modifier.width(8.dp)); Text("ادامهٔ مطالعه") }
                    OutlinedButton(onClick = onReview, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Style, null); Spacer(Modifier.width(8.dp)); Text("مرور فلش‌کارت‌ها") }
                    OutlinedButton(onClick = onSync, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.Sync, null); Spacer(Modifier.width(8.dp)); Text("همگام‌سازی با ویندوز") }
                    OutlinedButton(onClick = onToggleStudy, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.MoreTime, null); Spacer(Modifier.width(8.dp)); Text(if (studyStartAt == 0L) "شروع زمان‌سنج مطالعه" else "پایان و ثبت زمان مطالعه") }
                    OutlinedButton(onClick = onReports, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Default.CheckCircle, null); Spacer(Modifier.width(8.dp)); Text("گزارش پیشرفت") }
                }
            }
        }
        item { Text("کارهای باز", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        val openTasks = tasks.filter { !it.done }.take(5)
        if (openTasks.isEmpty()) item { EmptyState("کار باز ثبت نشده؛ می‌توانی برنامهٔ امروز را از بخش کارها بسازی.") }
        else items(openTasks, key = { it.id }) { task ->
            ListCard(title = task.title, subtitle = task.description.ifBlank { task.dueAt?.let { "موعد: ${PersianCalendar.fromEpoch(it)}" } ?: "بدون مهلت" }, trailing = "اولویت ${task.priority}", onClick = onTasks)
        }
    }
}

@Composable
private fun ReportsScreen(tasks: List<TaskEntity>, reviews: List<ReviewStateEntity>, sessions: List<StudySessionEntity>, chapters: List<ChapterEntity>) {
    val today = LocalDate.now()
    val startToday = today.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
    val startWeek = today.minusDays(((today.dayOfWeek.value + 1) % 7).toLong()).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
    val todaySeconds = sessions.filter { it.startedAt >= startToday }.sumOf { it.durationSeconds }
    val weekSeconds = sessions.filter { it.startedAt >= startWeek }.sumOf { it.durationSeconds }
    val completed = tasks.count { it.done }
    val overdue = tasks.count { !it.done && it.dueAt != null && it.dueAt < System.currentTimeMillis() }
    val dueCards = reviews.count { it.dueAt <= System.currentTimeMillis() }
    val hourFormat: (Long) -> String = { seconds -> "${seconds / 3600} ساعت و ${(seconds % 3600) / 60} دقیقه" }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("گزارش شخصی و آفلاین", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item { Text("اطلاعات فقط از داده‌های محلی همین گوشی محاسبه شده‌اند؛ تا زمان اضافه‌شدن همگام‌سازی پیشرفت، با گزارش ویندوز ادغام نمی‌شوند.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { StatCard("مطالعه امروز", hourFormat(todaySeconds), Icons.Default.MoreTime, Modifier.weight(1f)); StatCard("مطالعه این هفته", hourFormat(weekSeconds), Icons.Default.Dashboard, Modifier.weight(1f)) } }
        item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { StatCard("کارت سررسید", dueCards.toString(), Icons.Default.Style, Modifier.weight(1f)); StatCard("کار عقب‌افتاده", overdue.toString(), Icons.Default.TaskAlt, Modifier.weight(1f)) } }
        item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { StatCard("کار تکمیل‌شده", completed.toString(), Icons.Default.CheckCircle, Modifier.weight(1f)); StatCard("فصل محلی", chapters.size.toString(), Icons.Default.MenuBook, Modifier.weight(1f)) } }
        item { Text("جلسه‌های اخیر مطالعه", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
        val recent = sessions.sortedByDescending { it.startedAt }.take(20)
        if (recent.isEmpty()) item { EmptyState("هنوز جلسهٔ مطالعه‌ای ثبت نشده است.") }
        else items(recent, key = { "session-${it.id}" }) { session ->
            ListCard(title = session.activity, subtitle = "${PersianCalendar.fromEpoch(session.startedAt)} · ${session.durationSeconds / 60} دقیقه", trailing = chapters.firstOrNull { it.id == session.chapterId }?.title ?: "مطالعهٔ آزاد", onClick = {})
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Card(modifier) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) { Icon(icon, null, tint = MaterialTheme.colorScheme.primary); Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold); Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) } }
}

@Composable
private fun ChaptersScreen(chapters: List<ChapterEntity>, search: String, onSearch: (String) -> Unit, onOpen: (ChapterEntity) -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        OutlinedTextField(search, onSearch, Modifier.fillMaxWidth().padding(vertical = 8.dp), label = { Text("جست‌وجوی فصل یا موضوع") }, leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true)
        Text("${chapters.size} فصل روی گوشی", Modifier.padding(start = 8.dp, bottom = 6.dp), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        val filtered = chapters.filter { search.isBlank() || it.title.contains(search, true) || it.description.contains(search, true) || it.id.contains(search, true) }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
            items(filtered, key = { it.id }) { chapter ->
                Card(Modifier.fillMaxWidth().clickable { onOpen(chapter) }) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(Modifier.size(42.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) { Text(chapter.orderNum.toString(), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer) }
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(chapter.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                            Text(chapter.description.ifBlank { "${chapter.itemCount} مورد آموزشی · نسخه محلی ${chapter.downloadedAt.let { PersianCalendar.fromEpoch(it) }}" }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
            if (filtered.isEmpty()) item { EmptyState("فصلی پیدا نشد. از بخش همگام‌سازی محتوا را از ویندوز دریافت کن.") }
        }
    }
}

@Composable
private fun ChapterScreen(chapter: ChapterEntity?, items: List<ContentEntity>, onOpen: (ContentEntity) -> Unit, onQuiz: () -> Unit) {
    if (chapter == null) { EmptyState("فصل انتخاب‌شده در پایگاه محلی وجود ندارد."); return }
    var filter by remember(chapter.id) { mutableStateOf("all") }
    var query by remember(chapter.id) { mutableStateOf("") }
    val filters = listOf("all" to "همه", "lesson" to "درس", "note" to "نکته", "flashcard" to "کارت", "question" to "سؤال", "example" to "مثال", "lab" to "سناریو", "command" to "فرمان")
    val filtered = items.filter { (filter == "all" || it.kind == filter) && (query.isBlank() || it.title.contains(query, true) || it.content.contains(query, true)) }
    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        Text(chapter.description.ifBlank { "محتوای این فصل روی دستگاه ذخیره شده و پس از دانلود بدون شبکه در دسترس است." }, Modifier.padding(vertical = 8.dp), style = MaterialTheme.typography.bodyMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(query, { query = it }, Modifier.weight(1f), singleLine = true, label = { Text("جست‌وجو در فصل") })
            Button(onClick = onQuiz, enabled = items.any { it.kind == "question" }) { Text("آزمون") }
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            filters.forEach { (key, label) -> FilterChip(selected = filter == key, onClick = { filter = key }, label = { Text(label) }) }
        }
        Text("${filtered.size} مورد", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
            items(filtered, key = { it.uid }) { item ->
                ListCard(item.title, item.summary.ifBlank { kindName(item.kind) + " · " + item.sourceStatus }, "${item.seq}", { onOpen(item) })
            }
            if (filtered.isEmpty()) item { EmptyState("موردی با این فیلتر وجود ندارد.") }
        }
    }
}

@Composable
private fun ReaderScreen(item: ContentEntity, chapterTitle: String) {
    Column(Modifier.fillMaxSize()) {
        Surface(color = MaterialTheme.colorScheme.surfaceVariant) {
            Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(chapterTitle, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                Text(item.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("${kindName(item.kind)} · ${item.sourceStatus}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        when (item.kind) {
            "flashcard" -> FlashcardReader(item)
            "question" -> QuestionReader(item)
            else -> MarkdownBody(item.content.ifBlank { item.summary.ifBlank { "محتوایی برای این مورد ثبت نشده است." } }, Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 10.dp))
        }
    }
}

@Composable
private fun FlashcardReader(item: ContentEntity) {
    val meta = remember(item.metadataJson) { runCatching { JSONObject(item.metadataJson) }.getOrDefault(JSONObject()) }
    val front = meta.optString("front", item.title)
    val back = meta.optString("back", item.content.ifBlank { item.summary })
    var revealed by remember(item.uid) { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("روی کارت", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
        Card(Modifier.fillMaxWidth().heightIn(min = 180.dp).clickable { revealed = !revealed }) {
            Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                Text(if (revealed) back else front, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Medium)
            }
        }
        Spacer(Modifier.height(14.dp))
        Button(onClick = { revealed = !revealed }) { Text(if (revealed) "نمایش پرسش" else "نمایش پاسخ") }
    }
}

@Composable
private fun QuestionReader(item: ContentEntity) {
    val meta = remember(item.metadataJson, item.fullJson) {
        val m = runCatching { JSONObject(item.metadataJson) }.getOrDefault(JSONObject())
        if (!m.has("options")) {
            val full = runCatching { JSONObject(item.fullJson) }.getOrDefault(JSONObject())
            full.optJSONObject("metadata")?.let { nested -> nested.keys().forEach { k -> if (!m.has(k)) m.put(k, nested.opt(k)) } }
        }
        m
    }
    val options = remember(meta.toString()) { meta.optJSONArray("options") ?: JSONArray() }
    val correct = meta.optInt("correct_index", -1)
    val explanation = meta.optString("explanation", item.summary)
    var selected by remember(item.uid) { mutableIntStateOf(-1) }
    var checked by remember(item.uid) { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("پرسش", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
        Text(meta.optString("question", item.content.ifBlank { item.title }), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        for (i in 0 until options.length()) {
            val text = options.optString(i)
            Surface(shape = RoundedCornerShape(12.dp), color = if (checked && i == correct) MaterialTheme.colorScheme.primaryContainer else if (selected == i) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth().clickable(enabled = !checked) { selected = i }) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected == i, onClick = { if (!checked) selected = i }, enabled = !checked)
                    Text(text, Modifier.padding(start = 8.dp))
                }
            }
        }
        Button(onClick = { checked = true }, enabled = selected >= 0 && !checked, modifier = Modifier.fillMaxWidth()) { Text("بررسی پاسخ") }
        if (checked) {
            Text(if (selected == correct) "پاسخ درست است." else "پاسخ درست: ${options.optString(correct)}", fontWeight = FontWeight.Bold, color = if (selected == correct) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
            MarkdownBody(explanation, Modifier.fillMaxWidth())
            OutlinedButton(onClick = { checked = false; selected = -1 }, modifier = Modifier.fillMaxWidth()) { Text("دوباره پاسخ بده") }
        }
    }
}

@Composable
private fun QuizScreen(questions: List<ContentEntity>, onClose: () -> Unit) {
    var shuffled by remember(questions) { mutableStateOf(questions.shuffled()) }
    var index by remember(questions) { mutableIntStateOf(0) }
    var selected by remember(questions) { mutableIntStateOf(-1) }
    var checked by remember(questions) { mutableStateOf(false) }
    var correctCount by remember(questions) { mutableIntStateOf(0) }
    if (shuffled.isEmpty()) { EmptyState("سؤال آفلاین در این فصل پیدا نشد."); return }
    if (index >= shuffled.size) {
        Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.CheckCircle, null, Modifier.size(56.dp), tint = MaterialTheme.colorScheme.primary)
            Text("آزمون تمام شد", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("${correctCount} پاسخ درست از ${shuffled.size}", style = MaterialTheme.typography.titleLarge)
            Button(onClick = { shuffled = questions.shuffled(); index = 0; selected = -1; checked = false; correctCount = 0 }) { Text("آزمون دوباره") }
            TextButton(onClick = onClose) { Text("بازگشت به فصل") }
        }
        return
    }
    val q = shuffled[index]
    val meta = remember(q.uid) { runCatching { JSONObject(q.metadataJson) }.getOrDefault(JSONObject()) }
    val opts = meta.optJSONArray("options") ?: runCatching { JSONObject(q.fullJson).optJSONObject("metadata")?.optJSONArray("options") }.getOrNull() ?: JSONArray()
    val correct = meta.optInt("correct_index", runCatching { JSONObject(q.fullJson).optJSONObject("metadata")?.optInt("correct_index", -1) ?: -1 }.getOrDefault(-1))
    val explanation = meta.optString("explanation", q.summary)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        LinearProgressIndicator(progress = { (index + 1f) / shuffled.size }, modifier = Modifier.fillMaxWidth())
        Text("سؤال ${index + 1} از ${shuffled.size}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
        Text(meta.optString("question", q.content.ifBlank { q.title }), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        for (i in 0 until opts.length()) {
            Surface(shape = RoundedCornerShape(12.dp), color = if (checked && i == correct) MaterialTheme.colorScheme.primaryContainer else if (selected == i) MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.fillMaxWidth().clickable(enabled = !checked) { selected = i }) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) { RadioButton(selected == i, { if (!checked) selected = i }, enabled = !checked); Text(opts.optString(i), Modifier.padding(start = 8.dp)) }
            }
        }
        if (!checked) Button(onClick = { checked = true; if (selected == correct) correctCount++ }, enabled = selected >= 0, modifier = Modifier.fillMaxWidth()) { Text("ثبت پاسخ و نمایش توضیح") }
        if (checked) {
            Text(if (selected == correct) "درست" else "نادرست؛ پاسخ درست: ${opts.optString(correct)}", fontWeight = FontWeight.Bold, color = if (selected == correct) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
            MarkdownBody(explanation, Modifier.fillMaxWidth())
            Button(onClick = { index++; selected = -1; checked = false }, modifier = Modifier.fillMaxWidth()) { Text(if (index == shuffled.lastIndex) "نتیجه" else "سؤال بعدی") }
        }
    }
}

@Composable
private fun ReviewScreen(cards: List<ContentEntity>, reviewStates: List<ReviewStateEntity>, chapters: List<ChapterEntity>, onRate: (ContentEntity, String) -> Unit, onOpen: (ContentEntity) -> Unit) {
    var filter by remember { mutableStateOf("") }
    var showAll by remember { mutableStateOf(false) }
    var position by remember { mutableIntStateOf(0) }
    var revealed by remember { mutableStateOf(false) }
    val stateMap = remember(reviewStates) { reviewStates.associateBy { it.uid } }
    val selectedCards = cards.filter { card ->
        val chapter = chapters.firstOrNull { it.id == card.chapterId }
        (filter.isBlank() || chapter?.title?.contains(filter, true) == true || card.title.contains(filter, true)) &&
                (showAll || stateMap[card.uid]?.dueAt?.let { it <= System.currentTimeMillis() } != false)
    }
    val current = selectedCards.getOrNull(position.coerceAtMost((selectedCards.size - 1).coerceAtLeast(0)))
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("${selectedCards.size} کارت ${if (showAll) "در بانک" else "سررسیدشده/جدید"}", Modifier.weight(1f), fontWeight = FontWeight.Bold)
            TextButton(onClick = { showAll = !showAll; position = 0; revealed = false }) { Text(if (showAll) "فقط سررسیدشده" else "همهٔ کارت‌ها") }
        }
        OutlinedTextField(filter, { filter = it; position = 0 }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("فیلتر فصل یا عبارت") })
        if (current == null) EmptyState("کارتی مطابق فیلتر و زمان مرور پیدا نشد.")
        else {
            Text("${chapters.firstOrNull { it.id == current.chapterId }?.title ?: current.chapterId} · ${position + 1}/${selectedCards.size}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
            val meta = remember(current.uid) { runCatching { JSONObject(current.metadataJson) }.getOrDefault(JSONObject()) }
            val front = meta.optString("front", current.title)
            val back = meta.optString("back", current.content.ifBlank { current.summary })
            Card(Modifier.fillMaxWidth().weight(1f).clickable { revealed = !revealed }) {
                Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(if (revealed) "پاسخ" else "پرسش", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                        Text(if (revealed) back else front, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Medium)
                        Text("برای برگرداندن کارت لمس کن", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        TextButton(onClick = { onOpen(current) }) { Text("نمایش کامل محتوا") }
                    }
                }
            }
            if (!revealed) Button(onClick = { revealed = true }, Modifier.fillMaxWidth()) { Text("نمایش پاسخ") }
            else {
                Text("چقدر به یاد داشتی؟", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    listOf("again" to "دوباره", "hard" to "سخت", "good" to "خوب", "easy" to "آسان").forEach { (rating, label) ->
                        Button(onClick = { onRate(current, rating); position = (position + 1).coerceAtMost(selectedCards.size); revealed = false }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(horizontal = 3.dp)) { Text(label, fontSize = 11.sp) }
                    }
                }
            }
        }
    }
}

@Composable
private fun TasksScreen(tasks: List<TaskEntity>, onAdd: (String, String, Long?, Int) -> Unit, onToggle: (TaskEntity, Boolean) -> Unit, onDelete: (TaskEntity) -> Unit) {
    var showDialog by remember { mutableStateOf(false) }
    var filter by remember { mutableStateOf("today") }
    val today = LocalDate.now()
    val shown = tasks.filter { task -> when (filter) { "today" -> task.dueAt == null || Instant.ofEpochMilli(task.dueAt).atZone(ZoneId.systemDefault()).toLocalDate() == today; "open" -> !task.done; "done" -> task.done; else -> true } }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("کارها و برنامهٔ شخصی", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Button(onClick = { showDialog = true }) { Text("کار جدید +") }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("today" to "امروز", "open" to "باز", "done" to "انجام‌شده", "all" to "همه").forEach { (key,label) -> FilterChip(filter == key, { filter = key }, label = { Text(label) }) }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
            items(shown, key = { it.id }) { task ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(task.done, { onToggle(task, it) })
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text(task.title, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            if (task.description.isNotBlank()) Text(task.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text("اولویت ${task.priority}" + (task.dueAt?.let { " · موعد ${PersianCalendar.fromEpoch(it)}" } ?: " · بدون مهلت"), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        }
                        IconButton(onClick = { onDelete(task) }) { Icon(Icons.Default.Delete, "حذف کار") }
                    }
                }
            }
            if (shown.isEmpty()) item { EmptyState("کاری در این فیلتر وجود ندارد.") }
        }
    }
    if (showDialog) TaskDialog(onDismiss = { showDialog = false }, onSave = { title, desc, date, time, priority ->
        val due = if (date.isBlank()) null else PersianCalendar.toEpoch(date, time)
        onAdd(title, desc, due, priority); showDialog = false
    })
}

@Composable
private fun TaskDialog(onDismiss: () -> Unit, onSave: (String, String, String, String, Int) -> Unit) {
    var title by remember { mutableStateOf("") }; var desc by remember { mutableStateOf("") }
    var date by remember { mutableStateOf("") }; var time by remember { mutableStateOf("09:00") }; var priority by remember { mutableIntStateOf(2) }
    var validation by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("ساخت کار") }, text = {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(title, { title = it }, label = { Text("عنوان") }, singleLine = true)
            OutlinedTextField(desc, { desc = it }, label = { Text("شرح و یادداشت") }, minLines = 2)
            OutlinedTextField(date, { date = it }, label = { Text("موعد شمسی (مثلاً ۱۴۰۵/۰۸/۰۱؛ اختیاری)") }, singleLine = true)
            OutlinedTextField(time, { time = it }, label = { Text("ساعت ۲۴ساعته") }, singleLine = true)
            Text("اولویت", style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) { listOf(1 to "بالا", 2 to "عادی", 3 to "کم").forEach { (n,label) -> FilterChip(priority == n, { priority = n }, label = { Text(label) }) } }
            if (validation.isNotBlank()) Text(validation, color = MaterialTheme.colorScheme.error)
        }
    }, confirmButton = { Button(onClick = { try { require(title.isNotBlank()) { "عنوان را وارد کن." }; if (date.isNotBlank()) PersianCalendar.toEpoch(date, time); onSave(title.trim(), desc.trim(), date.trim(), time.trim(), priority) } catch (e: Exception) { validation = e.message ?: "اطلاعات نامعتبر است." } }) { Text("ذخیره") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } })
}

@Composable
private fun SyncSettingsScreen(serverUrl: String, onServerUrl: (String) -> Unit, password: String, onPassword: (String) -> Unit, progress: String, busy: Boolean, themeMode: String, onTheme: (String) -> Unit, onConnectSync: () -> Unit, onDisconnect: () -> Unit, onBackup: () -> Unit, onRestore: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("همگام‌سازی با ویندوز", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("ویندوز باید روشن باشد و سرور همگام‌سازی در همان شبکهٔ محلی فعال باشد. پس از دانلود، فصل‌ها و کارت‌ها به‌صورت آفلاین در دسترس‌اند.", style = MaterialTheme.typography.bodyMedium)
        OutlinedTextField(serverUrl, onServerUrl, Modifier.fillMaxWidth(), label = { Text("آدرس سرور، مانند http://192.168.1.20:8000/") }, singleLine = true, supportingText = { Text("از http فقط در شبکهٔ خصوصی مورداعتماد استفاده کن.") })
        OutlinedTextField(password, onPassword, Modifier.fillMaxWidth(), label = { Text("رمز شش‌کاراکتری ویندوز") }, singleLine = true, visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(), supportingText = { Text("پس از ورود موفق، نشست به‌شکل رمزگذاری‌شده روی دستگاه ذخیره می‌شود؛ خود رمز ذخیره نمی‌شود.") })
        Button(onClick = onConnectSync, enabled = !busy && serverUrl.isNotBlank(), modifier = Modifier.fillMaxWidth()) { if (busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp); Spacer(Modifier.width(8.dp)); Text(if (busy) "در حال همگام‌سازی…" else "اتصال / همگام‌سازی تغییرات") }
        OutlinedButton(onClick = onDisconnect, modifier = Modifier.fillMaxWidth()) { Text("قطع نشست ذخیره‌شده (فصل‌ها پاک نمی‌شوند)") }
        if (progress.isNotBlank()) Card(Modifier.fillMaxWidth()) { Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.CloudDownload, null, tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(8.dp)); Text(progress, style = MaterialTheme.typography.bodySmall) } }
        HorizontalDivider()
        Text("نمایش و مطالعه", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        listOf("system" to "مطابق سیستم", "light" to "روشن", "dark" to "تیره", "night" to "مطالعهٔ شب").forEach { (key,label) -> Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { onTheme(key) }.padding(6.dp), verticalAlignment = Alignment.CenterVertically) { RadioButton(themeMode == key, { onTheme(key) }); Text(label) } }
        HorizontalDivider()
        Text("پشتیبان محلی اندروید", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("شامل بانک محلی، کارها، سابقهٔ مرور، نشست‌های مطالعه، تنظیمات و رسانه‌های دانلودشده است. نشست/رمز سرور داخل فایل پشتیبان قرار نمی‌گیرد.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Button(onClick = onBackup, modifier = Modifier.fillMaxWidth()) { Text("ساخت پشتیبان کامل ZIP") }
        OutlinedButton(onClick = onRestore, modifier = Modifier.fillMaxWidth()) { Text("بازیابی پشتیبان ZIP یا JSON قدیمی") }
        Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.errorContainer) { Text("امنیت: سرور ویندوز نسخهٔ فعلی از HTTP در شبکهٔ محلی استفاده می‌کند. این آدرس را روی اینترنت عمومی منتشر نکن.", Modifier.padding(12.dp), color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable
private fun SearchScreen(query: String, onQuery: (String) -> Unit, chapters: List<ChapterEntity>, dao: LearningDao, onOpen: (ContentEntity) -> Unit) {
    var results by remember { mutableStateOf<List<ContentEntity>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        OutlinedTextField(query, onQuery, Modifier.fillMaxWidth(), label = { Text("جست‌وجو در درس، نکته، سؤال و کارت") }, singleLine = true,
            trailingIcon = { IconButton(onClick = { scope.launch { busy = true; results = withContext(Dispatchers.IO) { dao.searchContent(query) }; busy = false } }) { Icon(Icons.Default.Search, "جست‌وجو") } })
        Spacer(Modifier.height(8.dp))
        if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            items(results, key = { it.uid }) { item -> ListCard(item.title, chapters.firstOrNull { it.id == item.chapterId }?.title ?: item.chapterId, kindName(item.kind), { onOpen(item) }) }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun MarkdownBody(markdown: String, modifier: Modifier = Modifier) {
    val lines = remember(markdown) { markdown.replace("\r\n", "\n").split('\n') }
    SelectionContainer(modifier) {
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(vertical = 3.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            var codeBlock by remember(markdown) { mutableStateOf(false) }
            lines.forEachIndexed { index, line ->
                if (line.trimStart().startsWith("![") && line.contains("](")) {
                    MarkdownImageLine(line.trim())
                } else if (line.trimStart().startsWith("```")) {
                    codeBlock = !codeBlock
                } else if (line.isBlank()) {
                    Spacer(Modifier.height(4.dp))
                } else if (codeBlock) {
                    Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(6.dp), modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
                        Text(line, Modifier.padding(9.dp), fontFamily = FontFamily.Monospace, fontSize = 13.sp, lineHeight = 19.sp)
                    }
                } else {
                    val clean = line.replace(Regex("^#{1,6}\\s*"), "").removePrefix("> ").let { if (it.startsWith("- ") || it.startsWith("* ")) "• " + it.substring(2) else it }
                    when {
                        line.startsWith("# ") -> Text(clean, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 7.dp))
                        line.startsWith("## ") -> Text(clean, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
                        line.startsWith("### ") -> Text(clean, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 5.dp))
                        line.startsWith("> ") -> Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = RoundedCornerShape(8.dp)) { Text(clean, Modifier.padding(10.dp), color = MaterialTheme.colorScheme.onSecondaryContainer) }
                        line.trimStart().startsWith("|") -> Text(clean, fontFamily = FontFamily.Monospace, fontSize = 12.sp, modifier = Modifier.horizontalScroll(rememberScrollState()))
                        line.trimStart().startsWith("---") -> HorizontalDivider(Modifier.padding(vertical = 5.dp))
                        else -> Text(clean, style = MaterialTheme.typography.bodyLarge, lineHeight = 26.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun MarkdownImageLine(line: String) {
    val match = remember(line) { Regex("!\\[([^]]*)]\\(([^)]+)\\)").find(line) }
    val context = LocalContext.current
    val alt = match?.groupValues?.getOrNull(1).orEmpty()
    val rawPath = match?.groupValues?.getOrNull(2).orEmpty().trim()
    var expanded by remember(rawPath) { mutableStateOf(false) }
    val bitmap by produceState<Bitmap?>(initialValue = null, key1 = rawPath) {
        value = withContext(Dispatchers.IO) {
            try {
                if (rawPath.isBlank() || rawPath.startsWith("http", true)) null
                else {
                    val clean = rawPath.substringBefore('#').substringBefore('?').removePrefix("/media/").removePrefix("media/").removePrefix("/")
                    val root = File(context.filesDir, "media")
                    val f = File(root, clean)
                    if (!f.canonicalPath.startsWith(root.canonicalPath + File.separator) || !f.isFile) null
                    else {
                        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        BitmapFactory.decodeFile(f.absolutePath, bounds)
                        var sample = 1
                        while (bounds.outWidth / sample > 2400 || bounds.outHeight / sample > 2400) sample *= 2
                        BitmapFactory.decodeFile(f.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
                    }
                }
            } catch (_: Exception) { null }
        }
    }
    if (bitmap == null) {
        Text("[تصویر در حافظهٔ محلی موجود نیست: ${alt.ifBlank { rawPath }}]", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    } else {
        Card(Modifier.fillMaxWidth().clickable { expanded = true }) {
            Column(Modifier.padding(8.dp)) {
                Image(bitmap!!.asImageBitmap(), contentDescription = alt, modifier = Modifier.fillMaxWidth().heightIn(max = 280.dp), contentScale = ContentScale.Fit)
                Text(alt.ifBlank { "برای بزرگ‌نمایی تصویر لمس کن" }, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (expanded) {
            var scale by remember { mutableFloatStateOf(1f) }
            var offset by remember { mutableStateOf(Offset.Zero) }
            Dialog(onDismissRequest = { expanded = false; scale = 1f; offset = Offset.Zero }) {
                Surface(Modifier.fillMaxWidth().fillMaxHeight(0.92f), shape = RoundedCornerShape(18.dp), color = MaterialTheme.colorScheme.surface) {
                    Box(Modifier.fillMaxSize()) {
                        Image(bitmap!!.asImageBitmap(), contentDescription = alt, contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize().pointerInput(rawPath) {
                                detectTransformGestures { _, pan, zoom, _ ->
                                    scale = (scale * zoom).coerceIn(1f, 5f)
                                    offset = if (scale == 1f) Offset.Zero else offset + pan
                                }
                            }.graphicsLayer(scaleX = scale, scaleY = scale, translationX = offset.x, translationY = offset.y))
                        TextButton(onClick = { expanded = false; scale = 1f; offset = Offset.Zero }, modifier = Modifier.align(Alignment.TopEnd).padding(6.dp)) { Text("بستن") }
                        Text("بزرگ‌نمایی ${"%.1f".format(scale)}×", modifier = Modifier.align(Alignment.BottomCenter).padding(12.dp), color = MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
        }
    }
}

@Composable
private fun ListCard(title: String, subtitle: String, trailing: String = "", onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable { onClick() }) {
        Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            if (trailing.isNotBlank()) Text(trailing, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(start = 8.dp))
        }
    }
}

@Composable
private fun EmptyState(text: String) {
    Box(Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) { Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium) }
}

private fun kindName(kind: String): String = when (kind) {
    "lesson" -> "درس"; "flashcard" -> "فلش‌کارت"; "question" -> "سؤال"; "note" -> "نکته"; "example" -> "مثال"; "lab" -> "سناریو / آزمایشگاه"; "command" -> "مرجع فرمان"; "asset" -> "رسانه"; else -> kind
}

private fun nextReviewState(old: ReviewStateEntity, rating: String): ReviewStateEntity {
    val now = System.currentTimeMillis()
    val reps: Int
    val interval: Int
    val ease: Double
    val due: Long
    when (rating) {
        "again" -> {
            reps = 0; interval = 0; ease = (old.ease - 0.20).coerceAtLeast(1.3)
            due = now + 10 * 60 * 1000L
        }
        "hard" -> {
            reps = old.repetitions.coerceAtLeast(0); interval = (old.intervalDays * 1.2).toInt().coerceAtLeast(1)
            ease = (old.ease - 0.10).coerceAtLeast(1.3); due = now + 24 * 60 * 60 * 1000L
        }
        "easy" -> {
            reps = old.repetitions + 1; interval = (old.intervalDays * 2.8).toInt().coerceAtLeast(4)
            ease = old.ease + 0.10; due = now + interval.toLong() * 86400000L
        }
        else -> {
            reps = old.repetitions + 1; interval = if (old.intervalDays == 0) 1 else (old.intervalDays * old.ease).toInt().coerceAtLeast(2)
            ease = old.ease; due = now + interval.toLong() * 86400000L
        }
    }
    return ReviewStateEntity(old.uid, reps, interval, ease, due, now, rating)
}

private suspend fun buildBackup(db: AppDatabase): JSONObject = withContext(Dispatchers.IO) {
    val dao = db.learningDao(); val gson = Gson()
    fun array(values: List<Any>): JSONArray = JSONArray().also { arr -> values.forEach { arr.put(JSONObject(gson.toJson(it))) } }
    JSONObject().put("format", "netadmin-android-backup-v1")
        .put("created_at", System.currentTimeMillis())
        .put("chapters", array(dao.allChapters()))
        .put("content", array(dao.allContent()))
        .put("tasks", array(dao.allTasks()))
        .put("review_state", array(dao.allReviewStates()))
        .put("study_sessions", array(dao.allStudySessions()))
        .put("preferences", array(dao.allPreferences()))
}

private suspend fun writeBackupArchive(context: Context, db: AppDatabase, output: java.io.OutputStream) = withContext(Dispatchers.IO) {
    val json = buildBackup(db).toString(2).toByteArray(Charsets.UTF_8)
    ZipOutputStream(output.buffered()).use { zip ->
        zip.putNextEntry(ZipEntry("backup.json"))
        zip.write(json)
        zip.closeEntry()
        val mediaRoot = File(context.filesDir, "media")
        if (mediaRoot.isDirectory) {
            mediaRoot.walkTopDown().filter { it.isFile }.forEach { file ->
                val relative = file.relativeTo(context.filesDir).invariantSeparatorsPath
                require(!relative.startsWith("/") && relative.split('/').none { it == ".." }) { "مسیر رسانه برای پشتیبان امن نیست." }
                zip.putNextEntry(ZipEntry(relative))
                file.inputStream().buffered().use { it.copyTo(zip) }
                zip.closeEntry()
            }
        }
    }
}

private suspend fun restoreBackupArchive(context: Context, db: AppDatabase, rawInput: InputStream) = withContext(Dispatchers.IO) {
    val input = BufferedInputStream(rawInput)
    input.mark(8)
    val prefix = ByteArray(4)
    val read = input.read(prefix)
    input.reset()
    val isZip = read >= 2 && prefix[0] == 'P'.code.toByte() && prefix[1] == 'K'.code.toByte()
    if (!isZip) {
        val text = input.bufferedReader(Charsets.UTF_8).use { it.readText() }
        restoreBackup(db, JSONObject(text)) // backward compatibility with v1 JSON backups
        return@withContext
    }

    val tempRoot = File(context.cacheDir, "restore-${System.currentTimeMillis()}")
    val tempCanonical = tempRoot.canonicalPath + File.separator
    tempRoot.mkdirs()
    var uncompressed = 0L
    var entryCount = 0
    try {
        ZipInputStream(input).use { zip ->
            var entry = zip.nextEntry
            val buffer = ByteArray(64 * 1024)
            while (entry != null) {
                entryCount++
                require(entryCount <= 20_000) { "تعداد فایل‌های پشتیبان بیش از حد مجاز است." }
                val entryName = entry.name.replace('\\', '/')
                val safeParts = entryName.trimEnd('/').split('/')
                require(!entryName.startsWith('/') && safeParts.isNotEmpty() && safeParts.none { it == ".." || it == "." || it.isBlank() }) { "مسیر نامعتبر در پشتیبان." }
                val target = File(tempRoot, entryName)
                require(target.canonicalPath.startsWith(tempCanonical) || target.canonicalPath == tempRoot.canonicalPath) { "مسیر پشتیبان از پوشهٔ مجاز خارج شده است." }
                if (entry.isDirectory) {
                    target.mkdirs()
                } else {
                    target.parentFile?.mkdirs()
                    target.outputStream().buffered().use { out ->
                        while (true) {
                            val n = zip.read(buffer)
                            if (n <= 0) break
                            uncompressed += n
                            require(uncompressed <= 512L * 1024L * 1024L) { "حجم بازشدهٔ پشتیبان از ۵۱۲ مگابایت بیشتر است." }
                            out.write(buffer, 0, n)
                        }
                    }
                }
                zip.closeEntry()
                entry = zip.nextEntry
            }
        }
        val jsonFile = File(tempRoot, "backup.json")
        require(jsonFile.isFile && jsonFile.length() <= 256L * 1024L * 1024L) { "فایل backup.json داخل آرشیو نیست یا بیش از حد بزرگ است." }
        val json = JSONObject(jsonFile.readText(Charsets.UTF_8))
        require(json.optString("format") == "netadmin-android-backup-v1") { "قالب پشتیبان اندروید شناخته‌شده نیست." }

        // Stage media first; retain the old directory until the database transaction succeeds.
        val stagedMedia = File(tempRoot, "media")
        val targetMedia = File(context.filesDir, "media")
        val oldMedia = File(context.cacheDir, "media-before-restore-${System.currentTimeMillis()}")
        var movedOld = false
        try {
            if (targetMedia.exists()) {
                if (!targetMedia.renameTo(oldMedia)) throw IllegalStateException("امکان آماده‌سازی رسانه‌های قبلی برای بازیابی نبود.")
                movedOld = true
            }
            if (stagedMedia.exists()) {
                if (!stagedMedia.renameTo(targetMedia)) {
                    stagedMedia.copyRecursively(targetMedia, overwrite = true)
                }
            } else {
                targetMedia.mkdirs()
            }
            restoreBackup(db, json)
            if (movedOld) oldMedia.deleteRecursively()
        } catch (e: Exception) {
            targetMedia.deleteRecursively()
            if (movedOld) oldMedia.renameTo(targetMedia)
            throw e
        }
    } finally {
        tempRoot.deleteRecursively()
    }
}

private suspend fun restoreBackup(db: AppDatabase, json: JSONObject) = withContext(Dispatchers.IO) {
    require(json.optString("format") == "netadmin-android-backup-v1") { "قالب پشتیبان اندروید شناخته‌شده نیست." }
    val gson = Gson(); val dao = db.learningDao()
    db.withTransaction {
        dao.clearAllContent(); dao.clearChapters(); dao.clearTasks(); dao.clearReviewStates(); dao.clearStudySessions(); dao.clearPreferences()
        val chapters = json.optJSONArray("chapters") ?: JSONArray()
        for (i in 0 until chapters.length()) dao.upsertChapter(gson.fromJson(chapters.getJSONObject(i).toString(), ChapterEntity::class.java))
        val contents = json.optJSONArray("content") ?: JSONArray()
        val parsed = (0 until contents.length()).map { gson.fromJson(contents.getJSONObject(it).toString(), ContentEntity::class.java) }
        parsed.chunked(300).forEach { dao.upsertItems(it) }
        val tasks = json.optJSONArray("tasks") ?: JSONArray()
        for (i in 0 until tasks.length()) dao.upsertTask(gson.fromJson(tasks.getJSONObject(i).toString(), TaskEntity::class.java))
        val reviews = json.optJSONArray("review_state") ?: JSONArray()
        for (i in 0 until reviews.length()) dao.upsertReview(gson.fromJson(reviews.getJSONObject(i).toString(), ReviewStateEntity::class.java))
        val sessions = json.optJSONArray("study_sessions") ?: JSONArray()
        for (i in 0 until sessions.length()) dao.addStudySession(gson.fromJson(sessions.getJSONObject(i).toString(), StudySessionEntity::class.java))
        val preferences = json.optJSONArray("preferences") ?: JSONArray()
        for (i in 0 until preferences.length()) dao.setPreference(gson.fromJson(preferences.getJSONObject(i).toString(), PreferenceEntity::class.java))
    }
}

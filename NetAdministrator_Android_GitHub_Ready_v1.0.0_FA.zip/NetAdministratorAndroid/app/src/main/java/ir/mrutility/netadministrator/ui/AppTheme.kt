package ir.mrutility.netadministrator.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun NetAdminTheme(mode: String, content: @Composable () -> Unit) {
    val dark = when (mode) { "dark", "night" -> true; "light" -> false; else -> isSystemInDarkTheme() }
    val colors = if (dark) darkColorScheme(
        primary = Color(0xFF93C5FD), secondary = Color(0xFF80CBC4), tertiary = Color(0xFFD7B4FF),
        background = if (mode == "night") Color(0xFF080B11) else Color(0xFF101820),
        surface = if (mode == "night") Color(0xFF0D121A) else Color(0xFF17212B),
        surfaceVariant = if (mode == "night") Color(0xFF151C26) else Color(0xFF253341)
    ) else lightColorScheme(
        primary = Color(0xFF155E91), secondary = Color(0xFF176B62), tertiary = Color(0xFF6B4DB1),
        background = Color(0xFFF5F7FA), surface = Color(0xFFFFFFFF), surfaceVariant = Color(0xFFE7EDF3)
    )
    MaterialTheme(colorScheme = colors, content = content)
}

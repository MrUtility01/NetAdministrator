package ir.mrutility.netadministrator.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.CookieJar
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import androidx.room.withTransaction
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.MediaType.Companion.toMediaType
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

class SyncRepository(private val context: Context, private val db: AppDatabase) {
    private val cookieJar = SecureCookieJar(context)
    private val client: OkHttpClient = OkHttpClient.Builder()
        .cookieJar(cookieJar)
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .callTimeout(120, TimeUnit.SECONDS)
        .followRedirects(false)
        .build()
    private val prefs = context.getSharedPreferences("sync_configuration", Context.MODE_PRIVATE)

    fun savedBaseUrl(): String = prefs.getString("base_url", "") ?: ""
    fun hasSession(): Boolean = prefs.getString("base_url", null) != null
    fun clearSession() { cookieJar.clear() }

    suspend fun connectAndLogin(baseUrl: String, password: String): String = withContext(Dispatchers.IO) {
        val normalized = normalizeBaseUrl(baseUrl)
        val root = normalized.toHttpUrlOrNull() ?: throw SyncException("آدرس سرور معتبر نیست.")
        if (root.scheme == "http" && !isLocalHost(root.host)) {
            throw SyncException("برای HTTP فقط از آدرس محلی/خصوصی استفاده کن؛ برای سرور عمومی HTTPS لازم است.")
        }
        require(password.length == 6 && password.all { it.isLetterOrDigit() && it.code < 128 }) {
            "رمز سرور باید دقیقاً ۶ نویسه از حروف انگلیسی و عدد باشد."
        }
        val status = requestJson("GET", normalized + "api/auth/status")
        if (!status.optBoolean("configured", false)) throw SyncException("ابتدا رمز را روی خود رایانهٔ ویندوز از صفحهٔ محلی تنظیم کن.")
        val payload = JSONObject().put("password", password).toString()
            .toRequestBody("application/json; charset=utf-8".toMediaType())
        val result = requestJson("POST", normalized + "api/auth/login", payload)
        if (!result.optBoolean("ok", false)) throw SyncException("ورود به سرور موفق نبود.")
        prefs.edit().putString("base_url", normalized).apply()
        result.optString("message", "اتصال موفق بود.")
    }

    suspend fun syncAll(onProgress: (String) -> Unit = {}): SyncSummary = withContext(Dispatchers.IO) {
        val base = savedBaseUrl().ifBlank { throw SyncException("ابتدا آدرس سرور و رمز را وارد کن.") }
        onProgress("گرفتن فهرست تغییرات از ویندوز…")
        val manifest = requestJson("GET", base + "api/sync/manifest")
        if (manifest.optString("format") != "network-learning-sync-v1") throw SyncException("نسخهٔ پروتکل سرور سازگار نیست.")
        val serverChapters = manifest.optJSONArray("chapters") ?: JSONArray()
        var updated = 0
        var skipped = 0
        var itemsCount = 0
        val errors = mutableListOf<String>()
        for (i in 0 until serverChapters.length()) {
            val ch = serverChapters.getJSONObject(i)
            val id = ch.optString("id")
            val title = ch.optString("title", id)
            val hash = ch.optString("content_hash")
            onProgress("بررسی فصل ${i + 1} از ${serverChapters.length()}: $title")
            val local = db.learningDao().chapter(id)
            if (local != null && local.contentHash == hash) {
                // Retry missing/corrupt media even when the chapter JSON itself is unchanged.
                // A prior media error must not be hidden forever by a matching chapter hash.
                skipped++
                try {
                    downloadReferencedMedia(base, manifest, db.learningDao().chapterContent(id), onProgress, errors)
                } catch (e: Exception) {
                    errors.add("رسانه‌های فصل $title: ${e.message ?: "خطای نامشخص"}")
                }
                continue
            }
            try {
                val encodedId = java.net.URLEncoder.encode(id, "UTF-8").replace("+", "%20")
                val response = requestJson("GET", base + "api/sync/chapter/" + encodedId)
                if (response.optString("format") != "network-learning-sync-chapter-v1") throw SyncException("قالب فصل $title شناخته نشد.")
                val serverChapter = response.getJSONObject("chapter")
                val rawItems = response.optJSONArray("items") ?: JSONArray()
                val content = ArrayList<ContentEntity>(rawItems.length())
                for (j in 0 until rawItems.length()) {
                    val item = rawItems.getJSONObject(j)
                    val kind = item.optString("kind", "lesson")
                    val titleItem = item.optString("title", "مورد بدون عنوان")
                    val sourceUid = item.optString("source_uid").ifBlank { item.optString("id", "$id-$kind-$j") }
                    val uid = "$id:$sourceUid"
                    val metadata = item.optJSONObject("metadata")?.toString() ?: "{}"
                    content.add(ContentEntity(
                        uid = uid,
                        chapterId = id,
                        kind = kind,
                        title = titleItem,
                        summary = item.optString("summary", ""),
                        content = item.optString("content", ""),
                        sourceStatus = item.optString("source_status", "review_required"),
                        metadataJson = metadata,
                        fullJson = item.toString(),
                        seq = seqFor(item.optString("source_uid"), titleItem, j)
                    ))
                }
                val entity = ChapterEntity(
                    id = id,
                    title = serverChapter.optString("title", title),
                    description = serverChapter.optString("description", ch.optString("description", "")),
                    orderNum = serverChapter.optInt("order_num", i + 1),
                    contentHash = hash,
                    itemCount = content.size,
                    downloadedAt = System.currentTimeMillis()
                )
                // Replace a chapter atomically; the old version remains if conversion/download fails.
                db.withTransaction { db.learningDao().replaceChapter(entity, content) }
                itemsCount += content.size
                updated++
                downloadReferencedMedia(base, manifest, content, onProgress, errors)
            } catch (e: Exception) {
                errors.add("$title: ${e.message ?: "خطای نامشخص"}")
            }
        }
        SyncSummary(serverChapters.length(), updated, skipped, itemsCount, errors)
    }

    suspend fun search(query: String): List<ContentEntity> = withContext(Dispatchers.IO) {
        db.learningDao().searchContent(query.trim())
    }

    private suspend fun downloadReferencedMedia(
        base: String,
        manifest: JSONObject,
        items: List<ContentEntity>,
        onProgress: (String) -> Unit,
        errors: MutableList<String>
    ) {
        val all = manifest.optJSONArray("media_files") ?: return
        val haystack = items.joinToString(" ") { it.fullJson }
        val mediaRoot = File(context.filesDir, "media")
        for (i in 0 until all.length()) {
            val m = all.getJSONObject(i)
            val path = m.optString("path").trimStart('/')
            if (path.isBlank() || !haystack.contains(path) && !haystack.contains(File(path).name)) continue
            val target = File(mediaRoot, path)
            if (!target.canonicalPath.startsWith(mediaRoot.canonicalPath + File.separator)) {
                errors.add("مسیر رسانه نامعتبر بود: $path"); continue
            }
            val expected = m.optString("sha256")
            if (target.isFile && target.length() == m.optLong("size") && sha256(target).equals(expected, true)) continue
            try {
                onProgress("دریافت رسانه: ${File(path).name}")
                val urlPath = m.optString("url", "/media/$path").removePrefix("/")
                val url = base + urlPath.split('/').joinToString("/") { java.net.URLEncoder.encode(it, "UTF-8").replace("+", "%20") }
                val bytes = requestBytes(url)
                if (bytes.size.toLong() != m.optLong("size") || !sha256(bytes).equals(expected, true)) {
                    throw SyncException("هش یا اندازهٔ رسانه صحیح نیست.")
                }
                target.parentFile?.mkdirs()
                val temp = File(target.parentFile, target.name + ".part")
                FileOutputStream(temp).use { it.write(bytes); it.fd.sync() }
                if (!temp.renameTo(target)) { temp.delete(); throw SyncException("ثبت اتمی رسانه ناموفق بود.") }
            } catch (e: Exception) { errors.add("رسانهٔ $path: ${e.message}") }
        }
    }

    private fun requestJson(method: String, url: String, body: okhttp3.RequestBody? = null): JSONObject {
        val builder = Request.Builder().url(url).header("Accept", "application/json")
        when (method) { "POST" -> builder.post(body ?: "{}".toRequestBody("application/json".toMediaType())); "PUT" -> builder.put(body ?: "{}".toRequestBody("application/json".toMediaType())); else -> builder.get() }
        val response = client.newCall(builder.build()).execute()
        response.use {
            val text = it.body?.string().orEmpty()
            if (!it.isSuccessful) {
                if (it.code == 401) throw SyncException("نشست سرور منقضی یا نامعتبر است؛ دوباره وارد شو.")
                throw SyncException("سرور HTTP ${it.code} برگرداند: ${text.take(240)}")
            }
            return try { JSONObject(text) } catch (e: Exception) { throw SyncException("پاسخ سرور JSON معتبر نیست.") }
        }
    }

    private fun requestBytes(url: String): ByteArray {
        val response = client.newCall(Request.Builder().url(url).get().build()).execute()
        response.use {
            if (!it.isSuccessful) throw SyncException("دریافت فایل HTTP ${it.code}")
            return it.body?.bytes() ?: ByteArray(0)
        }
    }

    private fun normalizeBaseUrl(raw: String): String {
        var value = raw.trim()
        if (!value.startsWith("http://", true) && !value.startsWith("https://", true)) value = "http://$value"
        if (!value.endsWith('/')) value += "/"
        return value
    }

    private fun isLocalHost(host: String): Boolean {
        val h = host.lowercase()
        if (h == "localhost" || h.endsWith(".local") || h.endsWith(".lan")) return true
        val parts = h.split('.')
        if (parts.size != 4) return h == "::1" || h.startsWith("fe80:") || h.startsWith("fc") || h.startsWith("fd")
        val n = parts.mapNotNull { it.toIntOrNull() }
        if (n.size != 4 || n.any { it !in 0..255 }) return false
        return n[0] == 10 || n[0] == 127 || (n[0] == 192 && n[1] == 168) || (n[0] == 172 && n[1] in 16..31) || (n[0] == 169 && n[1] == 254)
    }

    

    private fun seqFor(uid: String, title: String, fallback: Int): Int {
        val md = Regex("(?:lesson|card|q|note|example|lab|cmd)[-_]?(\\d+)$", RegexOption.IGNORE_CASE).find(uid)
        if (md != null) return md.groupValues[1].toIntOrNull() ?: fallback
        val metaSeq = Regex("(?:^|\\D)(\\d{1,5})$").find(uid)
        return metaSeq?.groupValues?.getOrNull(1)?.toIntOrNull() ?: fallback
    }

    private fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(bytes).joinToString("") { "%02x".format(it) }
    private fun sha256(file: File): String = sha256(file.readBytes())

    suspend fun disconnect() = withContext(Dispatchers.IO) { cookieJar.clear(); prefs.edit().remove("base_url").apply() }
}

data class SyncSummary(
    val serverChapterCount: Int,
    val updatedChapters: Int,
    val unchangedChapters: Int,
    val downloadedItems: Int,
    val errors: List<String>
)

class SyncException(message: String) : Exception(message)

package ir.mrutility.netadministrator.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertThrows
import org.junit.Test
import java.time.LocalDate

class PersianCalendarTest {
    @Test fun persianDigitsNormalizeToAscii() {
        assertEquals("1405/08/01", PersianCalendar.normalizeDigits("۱۴۰۵/۰۸/۰۱"))
        assertEquals("1404/12/29", PersianCalendar.normalizeDigits("١٤٠٤/١٢/٢٩"))
    }

    @Test fun nowruzDatesRoundTrip() {
        assertEquals(LocalDate.of(2025, 3, 21), PersianCalendar.toGregorian("۱۴۰۴/۰۱/۰۱"))
        assertEquals("1404/01/01", PersianCalendar.fromGregorian(LocalDate.of(2025, 3, 21)))
        assertEquals(LocalDate.of(2026, 3, 21), PersianCalendar.toGregorian("1405/01/01"))
        assertEquals("1405/01/01", PersianCalendar.fromGregorian(LocalDate.of(2026, 3, 21)))
    }

    @Test fun rejectsImpossibleDate() {
        assertThrows(IllegalArgumentException::class.java) {
            PersianCalendar.toGregorian("۱۴۰۵/۰۱/۳۲")
        }
    }
}

# No shrinking in the first version. Rules are reserved for future release hardening.
